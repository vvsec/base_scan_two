# -*- coding:UTF-8 -*-

#10.10.10.x
#C段生成器的编写思路
# cipt = input('请输入C段，例如：10.10.10.x，注意x不需要写 \n'
#              '请输入：')
# for c in range(1,256):
#     print(cipt + str(c))

#B段生成器 , 计算有多少个C段生成
# bipt = input('请输入B段，例如：10.10.x，注意x不需要写 \n'
#               '请输入：')
# c_time = 0
# for b in range(1,256):
#     print(bipt + str(b))
#     for c in range(1,256):
#         c_time +=1
#         print(bipt + str(b)+ '.' +str(c))
#         if bipt + str(b)+ '.' +str(c) == bipt + '255.255':
#             print(c_time)
#         else:
#             pass
#子域名生成器
# 同时从26+10个数字里面提取指定长度的字符串-迭代器
# import itertools
# str = ['1','2','3','4']
# str2 = [5,8]
# f = '_'.join(iter(str))
# print(f)
# mylist=("_".join(x) for x in itertools.product("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ",repeat=16))
# while True:
#   print(next(mylist,‘-1’))
 # lists = (''.join())