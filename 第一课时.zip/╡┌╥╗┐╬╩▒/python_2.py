#-*- conding:UTF-8 -*-

#安装PyQt5 库：这边已经安装完毕
#安装PyQt5-tools库，这边也安装完毕了

#写一个pyqt5程序的流程

#设计界面
#逻辑与界面分离
#写逻辑
#运行打包（会有点问题，后面再进行解决，因为后面涉及到项目，咱们这节课以基础为主）

# class类:作用就是方便传参和调用，并继承父类直接调用
# class example:
#     def __init__(self,age,name):
#         self.age = age
#         self.name = name
#     def hello(self):
#         print('你好：%s,您的年龄是：%s' %(self.name,self.age))
#
# class examples(example):
#     def __init__(self,name='vvsec',age=17):
#         super().__init__(age,name)
#         self.hello()
#
# exps = examples()
